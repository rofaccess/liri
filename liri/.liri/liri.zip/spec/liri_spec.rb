RSpec.describe Liri, '#run' do
  it 'return true' do
    Liri.run
  end
end