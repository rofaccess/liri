module Sender
  class Ftp
    def send
    end
  end
end