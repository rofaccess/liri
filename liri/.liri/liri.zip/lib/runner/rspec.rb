module Runner
  class Rspec
    def run
      true
    end
  end
end