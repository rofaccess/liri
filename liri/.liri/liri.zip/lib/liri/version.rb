module Liri
  VERSION = "0.1.0"
end
