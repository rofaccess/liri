module Config
  COMPRESSED_SOURCE_CODE_TARGET_FOLDER = '.liri'
end